#include <stdio.h>
#include <unistd.h>

int main() {
    printf("Program started. Sleeping for 300 seconds...\n");
    sleep(300);
    printf("Program finished.\n");
    return 0;
}
